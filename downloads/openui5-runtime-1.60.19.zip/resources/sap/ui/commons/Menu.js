/*!
 * UI development toolkit for HTML5 (OpenUI5)
 * (c) Copyright 2009-2018 SAP SE or an SAP affiliate company.
 * Licensed under the Apache License, Version 2.0 - see LICENSE.txt.
 */
sap.ui.define(['jquery.sap.global','./MenuItemBase','./library','sap/ui/unified/Menu',"./MenuRenderer"],function(q,M,l,a,b){"use strict";var c=a.extend("sap.ui.commons.Menu",{metadata:{deprecated:true,library:"sap.ui.commons"}});c.prototype.bCozySupported=false;return c;},true);
