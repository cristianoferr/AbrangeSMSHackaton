/*!
 * UI development toolkit for HTML5 (OpenUI5)
 * (c) Copyright 2009-2018 SAP SE or an SAP affiliate company.
 * Licensed under the Apache License, Version 2.0 - see LICENSE.txt.
 */
sap.ui.define(['jquery.sap.global','sap/ui/commons/library','sap/ui/layout/form/FormLayout',"./FormLayoutRenderer"],function(q,l,F,a){"use strict";var b=F.extend("sap.ui.commons.form.FormLayout",{metadata:{deprecated:true,library:"sap.ui.commons"}});return b;},true);
