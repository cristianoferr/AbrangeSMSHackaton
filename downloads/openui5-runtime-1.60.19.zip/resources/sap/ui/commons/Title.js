/*!
 * UI development toolkit for HTML5 (OpenUI5)
 * (c) Copyright 2009-2018 SAP SE or an SAP affiliate company.
 * Licensed under the Apache License, Version 2.0 - see LICENSE.txt.
 */
sap.ui.define(['jquery.sap.global','./library','sap/ui/core/Title'],function(q,l,T){"use strict";var a=T.extend("sap.ui.commons.Title",{metadata:{deprecated:true,library:"sap.ui.commons"}});return a;},true);
